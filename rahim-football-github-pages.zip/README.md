# Rahim Football Tchad

Version statique prête pour GitHub Pages.

## Publication
1. Créez un dépôt GitHub.
2. Mettez `index.html`, `robots.txt`, `sitemap.xml` et le dossier `assets/` à la racine.
3. GitHub → Settings → Pages → Deploy from a branch → `main` → `/ (root)`.
4. Remplacez les URL `VOTRE-UTILISATEUR.github.io/VOTRE-DEPOT` dans `robots.txt` et `sitemap.xml`.
5. Le numéro WhatsApp utilisé par les commandes est `+235 62 49 61 76`.

## Produits
Le bouton « Ajouter produit » permet d'ajouter nom, prix, catégorie, description et photo.
Dans cette version 100% GitHub Pages, les produits sont enregistrés dans le navigateur avec localStorage.
Pour que les produits soient partagés avec tous les visiteurs, il faudra ensuite connecter une vraie base de données.
