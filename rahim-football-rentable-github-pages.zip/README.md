# Rahim Football Tchad — modèle rentable

Le site garde l'accès public gratuit et monétise les services professionnels :
- promotion de tournois ;
- annonces sponsorisées ;
- profils professionnels mis en avant ;
- vendeurs et commissions sur ventes, selon les conditions convenues ;
- à terme, abonnements professionnels et paiements automatisés.

Important : GitHub Pages ne fournit pas de base de données ni de paiement sécurisé. Cette version utilise WhatsApp pour les demandes de paiement. Pour automatiser les encaissements et comptabiliser les commissions, il faudra connecter une base de données + un prestataire de paiement disponible au Tchad.
